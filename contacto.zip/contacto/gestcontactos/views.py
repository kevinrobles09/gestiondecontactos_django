from django.shortcuts import redirect, render
from django.http import HttpResponse
from .models import databasecontactos

# Create your views here.

def index (request):
    #renderizamos el la plantilla index
    lista = databasecontactos.objects.all()
    return render (request, "index.html", {"todos":lista})

def agregar (request):
    #funcion para agregar contactos
    nombre = request.POST['txtNombre']
    apellido = request.POST['txtApellido']
    telefono = request.POST['txtTelefono']
    correo = request.POST['txtCorreo']

    insertar= databasecontactos.objects.create(nombre=nombre, apellido=apellido, telefono=telefono, correo=correo)
    #volvemos a la raiz
    return redirect('/')

def eliminar (request,telefono):
        #funcion para eliminar
    eliminar= databasecontactos.objects.get(telefono=telefono)
    eliminar.delete()
    return redirect('/')
    
