from django.db import models

# Creamos la base de datos.
class databasecontactos (models.Model):
    nombre=models.CharField(max_length=80)
    apellido=models.CharField(max_length=80)
    telefono=models.IntegerField(primary_key=True)
    correo=models.EmailField(max_length=256)

# constructor para texto
    def __str__(self):
        return self.nombre
    